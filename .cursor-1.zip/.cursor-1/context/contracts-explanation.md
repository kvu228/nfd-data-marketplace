# Giải Thích Các Smart Contracts - NFT-Based Data Marketplace

## Tổng Quan

Hệ thống NFT-Based Data Marketplace sử dụng **3 smart contracts chính** để quản lý việc tạo, giao dịch và truy vết tài sản số dưới dạng NFT:

1. **AssetAgreementFactory.sol** - Factory contract để tạo các AssetAgreement contracts
2. **AssetAgreement.sol** - ERC721A contract quản lý NFT cho mỗi chủ sở hữu
3. **AssetMarket.sol** - Market contract xử lý giao dịch mua/bán và phân phối royalty

## Kiến Trúc Tổng Quan

```
┌─────────────────────────────────────────┐
│   AssetAgreementFactory                 │
│   (Factory Pattern)                     │
└──────────────┬──────────────────────────┘
               │
               │ Tạo mới
               ▼
┌─────────────────────────────────────────┐
│   AssetAgreement (ERC721A)              │
│   - Mỗi chủ sở hữu có 1 contract       │
│   - Quản lý NFT và metadata             │
└──────────────┬──────────────────────────┘
               │
               │ Tương tác
               ▼
┌─────────────────────────────────────────┐
│   AssetMarket                           │
│   - Xử lý giao dịch                     │
│   - Phân phối royalty                    │
│   - Truy vết tài sản                    │
└─────────────────────────────────────────┘
```

---

## 1. AssetAgreementFactory.sol

### Mục Đích

Factory contract sử dụng **Factory Pattern** để tạo các `AssetAgreement` contracts mới cho mỗi chủ sở hữu dữ liệu.

### Cấu Trúc

```solidity
contract AssetAgreementFactory {
    event NewContract(address contractAddress);
    
    function createNewAssetAgreement(
        string memory _name,
        string memory _symbol,
        address _market
    ) public
}
```

### Cách Hoạt Động

1. **Tạo Contract Mới**:
   - Khi một chủ sở hữu muốn xuất bản tài sản lần đầu, hệ thống gọi `createNewAssetAgreement()`
   - Factory tạo một instance mới của `AssetAgreement` contract
   - Constructor của `AssetAgreement` nhận các tham số:
     - `_name`: Tên của NFT collection
     - `_symbol`: Ký hiệu của NFT collection
     - `msg.sender`: Địa chỉ của chủ sở hữu (người gọi hàm)
     - `_market`: Địa chỉ của Market contract

2. **Emit Event**:
   - Sau khi tạo thành công, contract emit event `NewContract` với địa chỉ của contract mới
   - Frontend có thể lắng nghe event này để lấy địa chỉ contract

### Ví Dụ Sử Dụng

```python
# Python wrapper
factory = AssetFactory(endpoint, factory_address, owner_address)
agreement_address, gas_used = factory.deploy_asset_agreement(
    name="My Collection",
    symbol="MC",
    market_address=market_address
)
```

### Đặc Điểm

- **Một Factory cho tất cả**: Chỉ cần deploy một Factory contract duy nhất
- **Mỗi chủ sở hữu một Agreement**: Mỗi chủ sở hữu có một `AssetAgreement` contract riêng
- **Event-driven**: Sử dụng events để thông báo contract mới được tạo

---

## 2. AssetAgreement.sol

### Mục Đích

Contract này là **ERC721A NFT contract** quản lý tài sản số cho một chủ sở hữu cụ thể. Mỗi chủ sở hữu có một `AssetAgreement` contract riêng.

### Inheritance

```solidity
contract AssetAgreement is ERC721A, AccessControl
```

- **ERC721A**: Standard NFT với tối ưu gas cho batch minting
- **AccessControl**: Quản lý phân quyền với roles

### Roles (Phân Quyền)

```solidity
bytes32 public constant MARKET_ROLE = keccak256("MARKET_ROLE");
bytes32 public constant OWNER_ROLE = keccak256("OWNER_ROLE");
```

- **OWNER_ROLE**: Chủ sở hữu gốc của agreement (người tạo contract)
- **MARKET_ROLE**: Market contract (được cấp quyền để xử lý giao dịch)

### Cấu Trúc Dữ Liệu

#### 1. DataAsset Struct

```solidity
struct DataAsset {
    uint256 price;          // Giá bán của tài sản
    bytes32 assetHash;      // Hash của tài sản có watermark
    bool forSale;           // Cờ cho biết tài sản có đang bán không
    bool resaleAllowed;     // Cho phép bán lại hay không
}
```

#### 2. Mappings

```solidity
mapping(uint256 => DataAsset) mintedAssets;  // tokenID → DataAsset
mapping(bytes32 => uint256) hashRecord;       // hash → tokenID
```

- `mintedAssets`: Lưu metadata của mỗi NFT theo token ID
- `hashRecord`: Mapping hash của tài sản có watermark sang token ID (dùng cho truy vết)

### Các Hàm Chính

#### 1. Constructor

```solidity
constructor(
    string memory _name,
    string memory _symbol,
    address _owner,
    address _market
) ERC721A(_name, _symbol)
```

- Khởi tạo ERC721A với tên và symbol
- Lưu địa chỉ owner và market
- Cấp quyền OWNER_ROLE cho owner và MARKET_ROLE cho market
- Tự động approve market contract để có thể transfer NFT

#### 2. mint() - Mint NFT

```solidity
function mint(
    uint256[] memory _prices,
    bool[] memory _resaleAllowed
) public onlyRole(OWNER_ROLE)
```

**Chức năng**:
- Mint một hoặc nhiều NFT (batch minting với ERC721A)
- Chỉ chủ sở hữu (OWNER_ROLE) mới có thể mint

**Quy trình**:
1. Kiểm tra độ dài mảng `_prices` và `_resaleAllowed` phải bằng nhau
2. Lấy token ID bắt đầu (`startTokenID`)
3. Gọi `_mint()` của ERC721A để mint NFT
4. Lấy token ID kết thúc (`endTokenID`)
5. Với mỗi token ID, set metadata:
   - `price`: Giá bán
   - `forSale`: Mặc định `true` (đang bán)
   - `resaleAllowed`: Quyền bán lại

**Ví dụ**:
```python
# Mint 1 NFT với giá 1 ETH, cho phép bán lại
agreement.mint(prices=[1.0], resaleAllowed=[True])
```

#### 3. updateHash() - Cập Nhật Hash

```solidity
function updateHash(
    uint256 _tokenId,
    bytes32 _hash
) public onlyRole(MARKET_ROLE)
```

**Chức năng**:
- Cập nhật hash của tài sản sau khi watermark
- Chỉ Market contract mới có thể gọi

**Quy trình**:
1. Kiểm tra token ID tồn tại
2. Lưu hash vào `hashRecord[_hash] = _tokenId` (dùng cho truy vết)
3. Cập nhật `mintedAssets[_tokenId].assetHash = _hash`

**Khi nào được gọi**:
- Sau khi người mua mua tài sản
- Hệ thống watermark tài sản với owner_id và buyer_id
- Tính hash của tài sản có watermark
- Gọi `updateHash()` để lưu hash lên blockchain

#### 4. getOwnerOfAssetFromHash() - Truy Vết Từ Hash

```solidity
function getOwnerOfAssetFromHash(
    bytes32 _hash
) public view returns (address, uint256)
```

**Chức năng**:
- Tìm chủ sở hữu hiện tại của tài sản từ hash của tài sản có watermark
- Trả về địa chỉ chủ sở hữu và token ID

**Quy trình**:
1. Tìm token ID từ `hashRecord[_hash]`
2. Kiểm tra token ID tồn tại
3. Xác minh hash khớp với hash trong `mintedAssets[tokenID]`
4. Trả về `ownerOf(tokenID)` và token ID

**Ứng dụng**:
- Truy vết quyền sở hữu từ hình ảnh có watermark
- Xác minh tính hợp lệ của tài sản

#### 5. updateSaleStatus() - Cập Nhật Trạng Thái Bán

```solidity
function updateSaleStatus(
    uint256 _tokenId,
    bool _status
) public onlyRole(MARKET_ROLE)
```

**Chức năng**:
- Cập nhật cờ `forSale` của tài sản
- Chỉ Market contract mới có thể gọi

**Logic**:
- Nếu set `forSale = true`, phải kiểm tra `resaleAllowed = true`
- Nếu `resaleAllowed = false`, không thể set `forSale = true`

**Khi nào được gọi**:
- Sau khi mua thành công: set `forSale = false`
- Khi chủ sở hữu muốn bán lại: set `forSale = true` (nếu được phép)

#### 6. updatePrice() - Cập Nhật Giá

```solidity
function updatePrice(
    uint256 _tokenId,
    uint256 _price
) public onlyRole(MARKET_ROLE)
```

**Chức năng**:
- Cập nhật giá bán của tài sản
- Chỉ Market contract mới có thể gọi (sau khi kiểm tra quyền sở hữu)

#### 7. updateAllowResaleStatus() - Cập Nhật Quyền Bán Lại

```solidity
function updateAllowResaleStatus(
    uint256 _tokenId,
    bool _status
) public onlyRole(OWNER_ROLE)
```

**Chức năng**:
- Cập nhật cờ `resaleAllowed`
- Chỉ chủ sở hữu gốc (OWNER_ROLE) mới có thể gọi
- **Quan trọng**: Phải là chủ sở hữu hiện tại của NFT (`ownerOf(_tokenId) == msg.sender`)

**Logic**:
- Chỉ chủ sở hữu gốc mới có thể thay đổi quyền bán lại
- Sau khi bán, người mua không thể thay đổi quyền này

#### 8. updateOwnerRoyalty() - Cập Nhật Royalty

```solidity
function updateOwnerRoyalty(uint256 _royalty) public onlyRole(OWNER_ROLE)
```

**Chức năng**:
- Cập nhật phần trăm royalty cho chủ sở hữu gốc
- Giá trị từ 0 đến 1 ether (0% đến 100%)
- Chỉ chủ sở hữu gốc mới có thể gọi

**Ví dụ**:
- `royalty = 0.1 ether` → 10% royalty
- `royalty = 0.5 ether` → 50% royalty

### Luồng Hoạt Động

#### Luồng Mint NFT (Xuất Bản Tài Sản)

```
1. Chủ sở hữu upload tài sản
   ↓
2. Hệ thống kiểm tra có AssetAgreement chưa
   - Chưa có → Tạo mới qua Factory
   - Đã có → Sử dụng contract hiện có
   ↓
3. Gọi mint() với:
   - prices: [giá bán]
   - resaleAllowed: [có cho phép bán lại không]
   ↓
4. NFT được mint với:
   - forSale = true
   - price = giá đã set
   - resaleAllowed = giá trị đã set
   ↓
5. Lưu thông tin vào database
```

#### Luồng Mua Tài Sản

```
1. Người mua chọn tài sản
   ↓
2. Hệ thống lấy thông tin từ blockchain:
   - price
   - owner
   - forSale status
   ↓
3. Tạo watermark với owner_id và buyer_id
   ↓
4. Tính hash của tài sản có watermark
   ↓
5. Gọi Market.updateHash() → AssetAgreement.updateHash()
   ↓
6. Gọi Market.purchase() với giá trị ETH
   ↓
7. Market contract:
   - Kiểm tra giá và trạng thái bán
   - Transfer NFT từ seller sang buyer
   - Set forSale = false
   - Phân phối payment (royalty)
```

---

## 3. AssetMarket.sol

### Mục Đích

Market contract là **trung tâm xử lý giao dịch**, quản lý việc mua/bán NFT và phân phối royalty fees.

### Inheritance

```solidity
contract AssetMarket is Ownable
```

- **Ownable**: Chỉ owner của contract mới có thể thay đổi một số cài đặt

### Re-entrancy Protection

```solidity
bool internal locked = false;

modifier noReEntrancy() {
    require(!locked, "Re-entrancy not allowed");
    locked = true;
    _;
    locked = false;
}
```

- Bảo vệ khỏi re-entrancy attacks bằng cách lock contract trong quá trình thực thi

### Cấu Trúc Dữ Liệu

```solidity
uint256 marketRoyalty = 0;  // Phần trăm royalty của market (0-1 ether)
```

### Các Hàm Chính

#### 1. purchase() - Mua Tài Sản

```solidity
function purchase(
    address _agreement,
    uint256 _tokenId
) public payable noReEntrancy
```

**Chức năng**:
- Xử lý giao dịch mua NFT
- Transfer ownership và phân phối payment

**Quy trình**:

1. **Kiểm tra giá**:
   ```solidity
   uint256 price = agreementContract.priceOf(_tokenId);
   require(msg.value >= price, "Not enough ETH!");
   ```

2. **Kiểm tra trạng thái bán**:
   ```solidity
   require(agreementContract.isForSale(_tokenId), "Asset is not for sale");
   ```

3. **Transfer NFT**:
   ```solidity
   address assetOwner = agreementContract.ownerOf(_tokenId);
   agreementContract.transferFrom(assetOwner, msg.sender, _tokenId);
   ```

4. **Cập nhật trạng thái**:
   ```solidity
   agreementContract.updateSaleStatus(_tokenId, false);
   ```

5. **Phân phối payment**:
   ```solidity
   processPayment(
       agreementContract.getOwner(),      // Chủ sở hữu gốc
       assetOwner,                        // Người bán hiện tại
       agreementContract.getOwnerRoyalty() // Royalty của chủ sở hữu gốc
   );
   ```

6. **Emit event**:
   ```solidity
   emit Purchase(assetOwner, msg.sender, _tokenId, price);
   ```

**Ví dụ**:
```python
# Người mua gửi 1 ETH để mua token ID 0
market.purchase(agreement_address, token_id=0, price=1.0)
```

#### 2. processPayment() - Phân Phối Payment

```solidity
function processPayment(
    address _originalOwner,
    address _seller,
    uint256 _ownerRoyalty
) private
```

**Chức năng**:
- Phân phối ETH từ người mua cho các bên liên quan
- Tính toán và trả royalty cho chủ sở hữu gốc và market

**Logic Phân Phối**:

```
Tổng số tiền: msg.value
    ↓
Market Royalty: msg.value * marketRoyalty / 1 ether
    ↓
Số tiền còn lại: msg.value - marketRoyalty
    ↓
┌─────────────────────────────────────┐
│ Nếu _originalOwner == _seller       │
│ (Bán lần đầu)                       │
│ → Chủ sở hữu gốc nhận: remaining    │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│ Nếu _originalOwner != _seller       │
│ (Bán lại)                           │
│ → Owner Royalty: remaining * _ownerRoyalty / 1 ether
│ → Seller nhận: remaining - ownerRoyalty
└─────────────────────────────────────┘
```

**Ví dụ**:
- Giá bán: 1 ETH
- Market royalty: 5% (0.05 ether)
- Owner royalty: 10% (0.1 ether)
- Người bán: Người mua cũ (không phải chủ sở hữu gốc)

```
Tổng: 1 ETH
Market: 0.05 ETH
Còn lại: 0.95 ETH
Owner (gốc): 0.95 * 0.1 = 0.095 ETH
Seller: 0.95 - 0.095 = 0.855 ETH
```

#### 3. updateHash() - Cập Nhật Hash

```solidity
function updateHash(
    address _agreement,
    uint256 _tokenId,
    bytes32 _hash
) public noReEntrancy onlyOwner
```

**Chức năng**:
- Cập nhật hash của tài sản sau khi watermark
- Chỉ owner của Market contract mới có thể gọi (thường là backend)

**Quy trình**:
1. Kiểm tra re-entrancy
2. Kiểm tra quyền (onlyOwner)
3. Gọi `agreementContract.updateHash(_tokenId, _hash)`

**Khi nào được gọi**:
- Sau khi watermark tài sản
- Trước khi thực hiện purchase transaction

#### 4. getAssetSaleRecord() - Truy Vết Giao Dịch

```solidity
function getAssetSaleRecord(
    address _agreement,
    bytes32 _hash
) public view returns (address, uint256)
```

**Chức năng**:
- Truy vết thông tin giao dịch từ hash của tài sản có watermark
- Trả về địa chỉ chủ sở hữu hiện tại và token ID

**Quy trình**:
1. Gọi `agreement.getOwnerOfAssetFromHash(_hash)`
2. Trả về kết quả

**Ứng dụng**:
- Xác minh quyền sở hữu từ hình ảnh có watermark
- Truy vết lịch sử giao dịch

#### 5. updateSaleStatus() - Cập Nhật Trạng Thái Bán

```solidity
function updateSaleStatus(
    address _agreement,
    uint256 _tokenId,
    bool _status
) public noReEntrancy
```

**Chức năng**:
- Cho phép chủ sở hữu NFT cập nhật trạng thái bán
- Kiểm tra quyền sở hữu trước khi cho phép

**Logic**:
```solidity
require(
    msg.sender == agreementContract.ownerOf(_tokenId),
    "Only Asset Owner can modify sale status"
);
```

#### 6. updatePrice() - Cập Nhật Giá

```solidity
function updatePrice(
    address _agreement,
    uint256 _tokenId,
    uint256 _price
) public noReEntrancy
```

**Chức năng**:
- Cho phép chủ sở hữu NFT cập nhật giá bán
- Kiểm tra quyền sở hữu

#### 7. updateMarketRoyalty() - Cập Nhật Market Royalty

```solidity
function updateMarketRoyalty(uint256 _newRoyalty) public onlyOwner
```

**Chức năng**:
- Cập nhật phần trăm royalty của market
- Chỉ owner của Market contract mới có thể gọi
- Giá trị từ 0 đến 1 ether (0% đến 100%)

#### 8. withdrawRoyalty() - Rút Royalty

```solidity
function withdrawRoyalty(address _to) public onlyOwner
```

**Chức năng**:
- Rút tất cả royalty fees tích lũy trong contract
- Chỉ owner của Market contract mới có thể gọi

---

## Luồng Tương Tác Giữa Các Contracts

### 1. Khởi Tạo Hệ Thống

```
1. Deploy AssetMarket
   ↓
2. Deploy AssetAgreementFactory (với market address)
   ↓
3. Hệ thống sẵn sàng
```

### 2. Chủ Sở Hữu Xuất Bản Tài Sản

```
Chủ sở hữu
   ↓
Factory.createNewAssetAgreement()
   ↓
Tạo AssetAgreement mới
   ↓
AssetAgreement.mint()
   ↓
NFT được mint với metadata
```

### 3. Người Mua Mua Tài Sản

```
Người mua
   ↓
Market.updateHash() → AssetAgreement.updateHash()
   (Lưu hash của tài sản có watermark)
   ↓
Market.purchase() với ETH
   ↓
AssetAgreement.transferFrom()
   (Transfer NFT)
   ↓
AssetAgreement.updateSaleStatus()
   (Set forSale = false)
   ↓
Market.processPayment()
   (Phân phối royalty)
```

### 4. Truy Vết Tài Sản

```
Có hình ảnh có watermark
   ↓
Tính hash của hình ảnh
   ↓
Market.getAssetSaleRecord()
   ↓
AssetAgreement.getOwnerOfAssetFromHash()
   ↓
Trả về owner và token ID
```

---

## Bảo Mật

### 1. Access Control

- **Role-based**: Sử dụng OpenZeppelin AccessControl
- **OWNER_ROLE**: Chỉ chủ sở hữu gốc mới có thể mint và thay đổi royalty
- **MARKET_ROLE**: Chỉ Market contract mới có thể update hash và price

### 2. Re-entrancy Protection

- Modifier `noReEntrancy` trong AssetMarket
- Lock mechanism để ngăn chặn re-entrancy attacks

### 3. Ownership Verification

- Kiểm tra `msg.sender == ownerOf(_tokenId)` trước khi cho phép thay đổi
- Đảm bảo chỉ chủ sở hữu mới có thể thay đổi giá và trạng thái bán

### 4. Input Validation

- Kiểm tra giá trị royalty (0-1 ether)
- Kiểm tra token existence
- Kiểm tra sale status trước khi mua

### 5. Payment Security

- Kiểm tra `msg.value >= price` trước khi mua
- Sử dụng `transfer()` để gửi ETH (có thể fail nếu recipient là contract)

---

## Đặc Điểm Nổi Bật

### 1. One-to-Many Relationship

- Mỗi chủ sở hữu có một `AssetAgreement` contract riêng
- Cho phép quản lý độc lập và tùy chỉnh royalty cho mỗi chủ sở hữu

### 2. Hash-based Traceability

- Hash của tài sản có watermark được lưu trên blockchain
- Cho phép truy vết quyền sở hữu từ hình ảnh có watermark

### 3. Royalty System

- **Owner Royalty**: Phần trăm cho chủ sở hữu gốc (có thể thay đổi)
- **Market Royalty**: Phần trăm cho market (có thể thay đổi)
- Tự động phân phối khi có giao dịch bán lại

### 4. Resale Control

- Chủ sở hữu gốc có thể kiểm soát quyền bán lại
- Nếu `resaleAllowed = false`, tài sản không thể bán lại sau khi mua

### 5. Batch Minting

- Sử dụng ERC721A để tối ưu gas khi mint nhiều NFT cùng lúc
- Giảm chi phí gas đáng kể so với ERC721 thông thường

---

## Tóm Tắt

### AssetAgreementFactory
- **Vai trò**: Factory để tạo AssetAgreement contracts
- **Pattern**: Factory Pattern
- **Chức năng**: Tạo contract mới cho mỗi chủ sở hữu

### AssetAgreement
- **Vai trò**: Quản lý NFT cho một chủ sở hữu
- **Standard**: ERC721A
- **Chức năng**: Mint NFT, quản lý metadata, truy vết hash

### AssetMarket
- **Vai trò**: Xử lý giao dịch và phân phối royalty
- **Chức năng**: Mua/bán NFT, phân phối payment, truy vết

Ba contracts này làm việc cùng nhau để tạo nên một hệ thống marketplace hoàn chỉnh với khả năng truy vết và quản lý royalty linh hoạt.

